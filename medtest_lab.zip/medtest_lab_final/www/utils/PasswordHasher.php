<?php
class PasswordHasher {
    // Hash a password using bcrypt
    public static function hash($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    function encrypt_password($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    function verify_password($password, $hash) {
        return password_verify($password, $hash);
    }

    // Verify a password against a hash
    public static function verify($password, $hash) {
        return password_verify($password, $hash);
    }

    // Generate a random salt
    public static function generateSalt($length = 22) {
        return bin2hex(random_bytes($length));
    }

    // Hash a password with a specific salt
    public static function hashWithSalt($password, $salt) {
        return password_hash($password . $salt, PASSWORD_BCRYPT, ['cost' => 12]);
    }
}
