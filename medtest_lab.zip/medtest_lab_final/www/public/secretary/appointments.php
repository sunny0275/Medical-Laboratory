<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'secretary') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$success = false;
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

// Handle appointment booking
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = filter_input(INPUT_POST, 'patient_id', FILTER_VALIDATE_INT);
    $test_code = $_POST['test_code'];
    $appointment_date = $_POST['appointment_date'];
    
    // Validate patient exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM patients WHERE patient_id = ?");
    $stmt->execute([$patient_id]);
    if ($stmt->fetchColumn() == 0) {
        $error = "Invalid patient selected";
    } else {
        try {
            $conn->beginTransaction();
            
            // Create order
            $stmt = $conn->prepare("INSERT INTO orders (patient_id, test_code, status) VALUES (?, ?, 'pending')");
            $stmt->execute([$patient_id, $test_code]);
            $order_id = $conn->lastInsertId();
            
            // Create appointment
            $stmt = $conn->prepare("INSERT INTO appointments (order_id, appointment_date, status) VALUES (?, ?, 'scheduled')");
            $stmt->execute([$order_id, $appointment_date]);
            
            // Create billing entry
            $stmt = $conn->prepare("
                INSERT INTO billing (order_id, amount, payment_status, insurance_claim_status)
                SELECT ?, cost, 'pending', 'not_submitted'
                FROM test_catalog WHERE test_code = ?
            ");
            $stmt->execute([$order_id, $test_code]);
            
            $conn->commit();
            $success = true;
        } catch (Exception $e) {
            $conn->rollBack();
            $error = $e->getMessage();
        }
    }
}
  // Get patients list with search
  $query = "
      SELECT 
          p.patient_id,
          COALESCE(decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)), '') as patient_name,
          COALESCE(decrypt_data(p.contact_info, (SELECT role FROM users WHERE id = p.userid)), '') as contact_info
      FROM patients p
      WHERE 1=1
  ";

  if ($searchTerm) {
      $query .= " AND (
          decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)) LIKE :search 
          OR p.patient_id LIKE :search_id
          OR decrypt_data(p.contact_info, (SELECT role FROM users WHERE id = p.userid)) LIKE :search_contact
      )";
  }
  $query .= " ORDER BY patient_name LIMIT 100";
$stmt = $conn->prepare($query);
if ($searchTerm) {
    $searchParam = "%$searchTerm%";
    $stmt->bindParam(':search', $searchParam);
    $stmt->bindParam(':search_id', $searchParam);
    $stmt->bindParam(':search_contact', $searchParam);
}
$stmt->execute();
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get test catalog
$tests = $conn->query("SELECT test_code, name, cost FROM test_catalog ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Appointment - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/common.css">
    <link rel="stylesheet" href="/assets/css/appointment.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo">MedTest Lab</div>
            <div class="nav-links">
                <a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>

        <div class="content">
            <h2><i class="fas fa-calendar-plus"></i> Book New Appointment</h2>
            
            <?php if ($success): ?>
                <div class="alert success">
                    <i class="fas fa-check-circle"></i> Appointment booked successfully!
                </div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert error">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <div class="search-section">
                <form method="GET" class="search-form">
                    <div class="search-group">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" 
                               name="search" 
                               placeholder="Search patient by name, ID, or contact info"
                               value="<?= htmlspecialchars($searchTerm) ?>">
                        <button type="submit" class="btn btn-search">Search</button>
                    </div>
                </form>
            </div>

            <form method="POST" class="booking-form">
                <div class="form-section">
                    <div class="form-group">
                        <label for="patient_id">
                            <i class="fas fa-user"></i> Select Patient
                        </label>
                        <select name="patient_id" id="patient_id" required>
                            <option value="">Choose Patient</option>
                            <?php foreach ($patients as $patient): ?>
                                <?php 
                                    $contactInfo = !empty($patient['contact_info']) ? 
                                        json_decode($patient['contact_info'], true) : 
                                        ['phone' => 'N/A'];
                                    $phone = $contactInfo['phone'] ?? 'N/A';
                                ?>
                                <option value="<?= htmlspecialchars($patient['patient_id']) ?>">
                                    #<?= htmlspecialchars($patient['patient_id']) ?> | 
                                    <?= htmlspecialchars($patient['patient_name']) ?> | 
                                    📞 <?= htmlspecialchars($phone) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($patients) && $searchTerm): ?>
                            <p class="no-results">
                                <i class="fas fa-info-circle"></i> No patients found matching your search.
                            </p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="test_code">
                            <i class="fas fa-vial"></i> Select Test
                        </label>
                        <select name="test_code" id="test_code" required>
                            <option value="">Choose Test</option>
                            <?php foreach ($tests as $test): ?>
                                <option value="<?= htmlspecialchars($test['test_code']) ?>">
                                    <?= htmlspecialchars($test['name']) ?> - 
                                    $<?= htmlspecialchars(number_format($test['cost'], 2)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="appointment_date">
                            <i class="fas fa-clock"></i> Appointment Date & Time
                        </label>
                        <input type="datetime-local"
                               id="appointment_date"
                               name="appointment_date"
                               required
                               min="<?= date('Y-m-d\TH:i') ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-calendar-check"></i> Book Appointment
                    </button>
                    <a href="../dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
