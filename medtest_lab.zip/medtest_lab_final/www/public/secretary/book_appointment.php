
<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'secretary') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$success = false;

// Handle appointment booking
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    
    // Validate patient exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM patients WHERE patient_id = ?");
    $stmt->execute([$patient_id]);
    if ($stmt->fetchColumn() == 0) {
        $error = "Invalid patient selected";
    } else {
        // Rest of your existing booking logic
        $test_code = $_POST['test_code'];
        $appointment_date = $_POST['appointment_date'];
        
        try {
            // Your existing transaction code...
        } catch (Exception $e) {
            $conn->rollBack();
            $error = $e->getMessage();
        }
    }
}

// Get patients list with search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchQuery = "
    SELECT 
        p.patient_id,
        decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)) as patient_name,
        decrypt_data(p.contact_info, (SELECT role FROM users WHERE id = p.userid)) as contact_info
    FROM patients p
    WHERE 
        decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)) LIKE :search 
        OR p.patient_id LIKE :search_id
    ORDER BY patient_name
    LIMIT 100
";

$stmt = $conn->prepare($searchQuery);
$stmt->execute([
    ':search' => "%$search%",
    ':search_id' => "%$search%"
]);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Rest of your existing code...
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Appointment - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/appointment.css">
    <script>
        function searchPatients() {
            const search = document.getElementById('patient_search').value;
            window.location.href = `?search=${encodeURIComponent(search)}`;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Book New Appointment</h2>
        
        <?php if ($success): ?>
            <div class="alert success">Appointment booked successfully!</div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="booking-form">
            <div class="form-group">
                <label for="patient_search">Search Patient</label>
                <div class="search-container">
                    <input type="text" 
                           id="patient_search" 
                           placeholder="Search by name or ID..."
                           value="<?= htmlspecialchars($search) ?>">
                    <button type="button" onclick="searchPatients()">Search</button>
                </div>
                
                <select name="patient_id" required size="5">
                    <option value="">Choose Patient</option>
                    <?php foreach ($patients as $patient): ?>
                        <?php 
                            $contactInfo = json_decode($patient['contact_info'], true);
                            $phone = $contactInfo['phone'] ?? 'N/A';
                        ?>
                        <option value="<?= htmlspecialchars($patient['patient_id']) ?>">
                            ID: <?= htmlspecialchars($patient['patient_id']) ?> | 
                            <?= htmlspecialchars($patient['patient_name']) ?> |
                            Phone: <?= htmlspecialchars($phone) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($patients)): ?>
                    <p class="no-results">No patients found. Please try a different search.</p>
                <?php endif; ?>
            </div>

            <!-- Rest of your existing form code... -->
        </form>

        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
