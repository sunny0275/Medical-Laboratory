<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'secretary') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$success = isset($_GET['success']);

// Process payment status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['billing_id'])) {
    $billing_id = $_POST['billing_id'];
    $payment_status = $_POST['payment_status'];
    $payment_method = $_POST['payment_method'];
    
    $stmt = $conn->prepare("UPDATE billing SET payment_status = ?, payment_method = ?, payment_date = NOW() WHERE billing_id = ?");
    if ($stmt->execute([$payment_status, $payment_method, $billing_id])) {
        header('Location: billing.php?success=1');
        exit();
    }
}

// Get only unpaid billing records
$stmt = $conn->prepare("
    SELECT
        b.billing_id,
        b.order_id,
        COALESCE(decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)), '') as patient_name,
        tc.name as test_name,
        b.amount,
        b.payment_status,
        b.payment_method,
        DATE_FORMAT(b.payment_date, '%Y-%m-%d %H:%i') as payment_date
    FROM billing b
    JOIN orders o ON b.order_id = o.order_id
    JOIN patients p ON o.patient_id = p.patient_id
    JOIN test_catalog tc ON o.test_code = tc.test_code
    WHERE b.payment_status = 'pending'
    ORDER BY b.payment_date DESC
");
$stmt->execute();
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Management</title>
    <link rel="stylesheet" href="/assets/css/billing.css">
</head>
<body>
    <div class="container">
        <h2>Payment Management</h2>
        
        <?php if ($success): ?>
            <div class="alert success">Payment Status Updated Successfully!</div>
        <?php endif; ?>

        <table class="payment-table">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Test</th>
                    <th>Amount</th>
                    <th>Payment Status</th>
                    <th>Payment Method</th>
                    <th>Payment Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($payments)): ?>
                    <tr>
                        <td colspan="7" class="text-center">No pending payments found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td><?= htmlspecialchars($payment['patient_name']) ?></td>
                            <td><?= htmlspecialchars($payment['test_name']) ?></td>
                            <td>$<?= htmlspecialchars(number_format($payment['amount'], 2)) ?></td>
                            <td><?= htmlspecialchars(ucfirst($payment['payment_status'] ?? 'pending')) ?></td>
                            <td><?= htmlspecialchars(str_replace('_', ' ', $payment['payment_method'] ?? 'Not selected')) ?></td>
                            <td><?= htmlspecialchars($payment['payment_date'] ?? 'Not paid') ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="billing_id" value="<?= htmlspecialchars($payment['billing_id']) ?>">
                                    <select name="payment_status">
                                        <option value="pending" <?= $payment['payment_status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="paid" <?= $payment['payment_status'] == 'paid' ? 'selected' : '' ?>>Paid</option>
                                        <option value="cancelled" <?= $payment['payment_status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                    </select>
                                    <select name="payment_method">
                                        <option value="">Select Payment Method</option>
                                        <option value="Cash" <?= $payment['payment_method'] == 'Cash' ? 'selected' : '' ?>>Cash</option>
                                        <option value="Credit_card" <?= $payment['payment_method'] == 'Credit_card' ? 'selected' : '' ?>>Credit Card</option>
                                        <option value="Alipay" <?= $payment['payment_method'] == 'Alipay' ? 'selected' : '' ?>>Alipay</option>
                                        <option value="WeChat" <?= $payment['payment_method'] == 'WeChat' ? 'selected' : '' ?>>WeChat</option>
                                        <option value="PayPal" <?= $payment['payment_method'] == 'PayPal' ? 'selected' : '' ?>>PayPal</option>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
