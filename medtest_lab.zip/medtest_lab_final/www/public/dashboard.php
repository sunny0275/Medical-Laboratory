<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';

if (!check_auth()) {
    header('Location: login.php');
    exit();
}

$conn = get_db_connection();
$stmt = $conn->prepare("SELECT username, role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: logout.php');
    exit();
}

$role = $_SESSION['role'];
$data = [];

try {
    switch($role) {
        case 'admin':
            $data['System Overview'] = [
                'Total Users' => $conn->query("SELECT COUNT(*) FROM users")->fetchColumn(),
                'Total Orders' => $conn->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
                'Active Staff' => $conn->query("SELECT COUNT(*) FROM staff")->fetchColumn(),
                'Test Types' => $conn->query("SELECT COUNT(*) FROM test_catalog")->fetchColumn()
            ];
        
            $data['Security Monitoring'] = $conn->query("
                SELECT 
                    DATE_FORMAT(query_time, '%Y-%m-%d %H:%i') as timestamp,
                    query_text,
                    suspicious
                FROM query_log
                WHERE suspicious = TRUE
                ORDER BY query_time DESC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
        
            $data['Recent Orders'] = $conn->query("
                SELECT 
                    o.order_id,
                    tc.name as test_name,
                    o.status,
                    DATE_FORMAT(o.order_date, '%Y-%m-%d %H:%i') as order_date,
                    COALESCE(b.payment_status, 'pending') as payment_status
                FROM orders o
                JOIN test_catalog tc ON o.test_code = tc.test_code
                LEFT JOIN billing b ON o.order_id = b.order_id
                ORDER BY o.order_date DESC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
        
            $data['Staff Distribution'] = $conn->query("
                SELECT 
                    role,
                    COUNT(*) as count
                FROM staff
                GROUP BY role
                ORDER BY count DESC
            ")->fetchAll(PDO::FETCH_ASSOC);
            break;
            


        case 'lab_staff':
            $data['Current Workload'] = [
                'Pending Tests' => $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn(),
                'Sampling Tests' => $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'sampling'")->fetchColumn(),
                'Completed Tests' => $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'")->fetchColumn()
            ];
        
            $data['Tests To Process'] = $conn->query("
                SELECT 
                    o.order_id,
                    COALESCE(decrypt_data(pd.name, (SELECT role FROM users WHERE id = pd.userid)), '') as patient_name,
                    tc.name as test_name,
                    o.status,
                    DATE_FORMAT(o.order_date, '%Y-%m-%d %H:%i') as order_date
                FROM orders o
                JOIN patients pd ON o.patient_id = pd.patient_id
                JOIN test_catalog tc ON o.test_code = tc.test_code
                WHERE o.status IN ('pending', 'sampling')
                ORDER BY o.order_date ASC
            ")->fetchAll(PDO::FETCH_ASSOC);        
        
            $data['Completed Tests'] = $conn->query("
                SELECT 
                    o.order_id,
                    COALESCE(decrypt_data(pd.name, (SELECT role FROM users WHERE id = pd.userid)), '') as patient_name,
                    tc.name as test_name,
                    COALESCE(decrypt_data(r.interpretation, 'lab_staff'), '') as interpretation,
                    DATE_FORMAT(r.created_at, '%Y-%m-%d %H:%i') as completion_date
                FROM orders o
                JOIN patients pd ON o.patient_id = pd.patient_id
                JOIN test_catalog tc ON o.test_code = tc.test_code
                JOIN results r ON o.order_id = r.order_id
                WHERE o.status = 'completed'
                ORDER BY r.created_at DESC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'secretary':
            $data['Today\'s Overview'] = [
                'Today\'s Appointments' => $conn->query("SELECT COUNT(*) FROM appointments WHERE DATE(appointment_date) = CURDATE()")->fetchColumn(),
                'Pending Payments' => $conn->query("SELECT COUNT(*) FROM billing WHERE payment_status = 'pending'")->fetchColumn()
            ];
        
            $data['Recent Appointments'] = $conn->query("
                SELECT
                    DATE_FORMAT(a.appointment_date, '%Y-%m-%d %H:%i') as appointment_time,
                    COALESCE(decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)), '') as patient_name,
                    p.patient_id,
                    tc.name as test_name,
                    b.payment_status
                FROM appointments a
                JOIN orders o ON a.order_id = o.order_id
                JOIN patients p ON o.patient_id = p.patient_id
                JOIN test_catalog tc ON o.test_code = tc.test_code
                LEFT JOIN billing b ON o.order_id = b.order_id
                WHERE a.appointment_date >= CURDATE()
                ORDER BY a.appointment_date ASC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
        
            $data['Pending Payments'] = $conn->query("
                SELECT
                    COALESCE(decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)), '') as patient_name,
                    p.patient_id,
                    tc.name as test_name,
                    b.amount,
                    b.payment_status
                FROM billing b
                JOIN orders o ON b.order_id = o.order_id
                JOIN patients p ON o.patient_id = p.patient_id
                JOIN test_catalog tc ON o.test_code = tc.test_code
                WHERE b.payment_status = 'pending'
                ORDER BY o.order_date ASC
                LIMIT 10
            ")->fetchAll(PDO::FETCH_ASSOC);
            break;
            

        case 'patient':
            // Get patient profile with proper JSON handling
            $stmt = $conn->prepare("
                SELECT
                    COALESCE(decrypt_data(name, (SELECT role FROM users WHERE id = userid)), '') as name,
                    JSON_UNQUOTE(JSON_EXTRACT(COALESCE(decrypt_data(contact_info, (SELECT role FROM users WHERE id = userid)), '{}'), '$.phone')) as phone,
                    JSON_UNQUOTE(JSON_EXTRACT(COALESCE(decrypt_data(contact_info, (SELECT role FROM users WHERE id = userid)), '{}'), '$.address')) as address,
                    JSON_UNQUOTE(JSON_EXTRACT(COALESCE(decrypt_data(insurance_details, (SELECT role FROM users WHERE id = userid)), '{}'), '$.provider')) as insurance_provider,
                    JSON_UNQUOTE(JSON_EXTRACT(COALESCE(decrypt_data(insurance_details, (SELECT role FROM users WHERE id = userid)), '{}'), '$.policy')) as policy_number
                FROM patients
                WHERE userid = ?
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $data['My Profile'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
            // Get patient test history with comprehensive details
            $stmt = $conn->prepare("
                SELECT
                    tc.name as test_name,
                    CASE
                        WHEN a.appointment_date IS NULL THEN 'Not yet scheduled'
                        ELSE DATE_FORMAT(a.appointment_date, '%Y-%m-%d %H:%i')
                    END as appointment_time,
                    o.status as test_status,
                    COALESCE(b.amount, 0) as cost,
                    b.payment_status,
                    b.insurance_claim_status,
                    CASE
                        WHEN r.result_id IS NOT NULL THEN 'Results Available'
                        WHEN o.status = 'completed' THEN 'Processing Results'
                        WHEN o.status = 'sampling' THEN 'Sample Collection'
                        WHEN o.status = 'pending' THEN 'Waiting for Test'
                        ELSE 'Not Started'
                    END as result_status
                FROM orders o
                JOIN test_catalog tc ON o.test_code = tc.test_code
                LEFT JOIN appointments a ON o.order_id = a.order_id
                LEFT JOIN billing b ON o.order_id = b.order_id
                LEFT JOIN results r ON o.order_id = r.order_id
                WHERE o.patient_id = (SELECT patient_id FROM patients WHERE userid = ?)
                ORDER BY a.appointment_date DESC
            ");
        
            $stmt->execute([$_SESSION['user_id']]);
            $data['My Tests'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $data['error'] = ['message' => 'A database error occurred'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedTest Lab - Dashboard</title>
    <link rel="stylesheet" href="/assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <div class="user-info">
                <h3><?php echo htmlspecialchars($user['username']); ?></h3>
                <span class="role"><?php echo htmlspecialchars($user['role']); ?></span>
            </div>
            
            <nav class="nav-menu">
                <?php if($role === 'admin'): ?>
                    <a href="admin/manage_users.php" class="nav-item">User Management</a>
                    <a href="admin/manage_staff.php" class="nav-item">Staff Management</a>
                    <a href="admin/test_catalog.php" class="nav-item">Test Catalog</a>
                    <a href="admin/security_logs.php" class="nav-item">Security Logs</a>
                <?php endif; ?>


                <?php if($role === 'lab_staff'): ?>
                    <a href="lab_staff/record_result.php" class="nav-item">Record Test Results</a>
                <?php endif; ?>
                
                <?php if($role === 'secretary'): ?>
                    <a href="secretary/appointments.php" class="nav-item">Schedule Tests</a>
                    <a href="secretary/billing.php" class="nav-item">Process Payments</a>
                <?php endif; ?>
                
                <?php if($role === 'patient'): ?>
                    <a href="patient/results.php" class="nav-item">View Results</a>
                <?php endif; ?>
                
                <a href="logout.php" class="nav-item logout">Logout</a>
            </nav>
        </aside>

        <main class="content">
            <?php if (isset($data['error'])): ?>
                <div class="error-alert">
                    <?php echo htmlspecialchars($data['error']['message']); ?>
                </div>
            <?php else: ?>
                <?php foreach ($data as $section => $content): ?>
                    <section class="data-section">
                        <h2><?php echo htmlspecialchars($section); ?></h2>
                        
                        <?php if (is_array($content) && isset($content[0])): ?>
                            <div class="table-wrapper">
                                <table>
                                    <thead>
                                        <tr>
                                            <?php foreach ($content[0] as $column => $value): ?>
                                                <th><?php echo htmlspecialchars(str_replace('_', ' ', $column)); ?></th>
                                            <?php endforeach; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($content as $row): ?>
                                            <tr>
                                                <?php foreach ($row as $value): ?>

                                                    <td><?php echo htmlspecialchars((string)$value); ?></td>
                                                <?php endforeach; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="stats-grid">
                                <?php foreach ($content as $label => $value): ?>
                                    <div class="stat-card">
                                        <h4><?php echo htmlspecialchars($label); ?></h4>
                                        <div class="value"><?php echo htmlspecialchars($value); ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endforeach; ?>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
