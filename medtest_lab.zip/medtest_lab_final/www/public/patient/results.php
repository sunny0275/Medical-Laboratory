<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'patient') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();

$stmt = $conn->prepare("
    SELECT
        o.order_id,
        tc.name as test_name,
        tc.description as test_description,
        DATE_FORMAT(r.created_at, '%Y-%m-%d %H:%i') as result_date,
        decrypt_data(r.interpretation, 'lab_staff') as interpretation,
        decrypt_data(r.report_url, 'lab_staff') as report_url,
        CASE
            WHEN r.result_id IS NOT NULL THEN 'Results Available'
            WHEN o.status = 'completed' THEN 'Processing Results'
            WHEN o.status = 'sampling' THEN 'Sample Collection'
            WHEN o.status = 'pending' THEN 'Waiting for Test'
            ELSE 'Not Started'
        END as result_status,
        o.status
    FROM orders o
    JOIN test_catalog tc ON o.test_code = tc.test_code
    LEFT JOIN results r ON o.order_id = r.order_id
    WHERE o.patient_id = (SELECT patient_id FROM patients WHERE userid = ?)
    ORDER BY r.created_at DESC, o.order_date DESC
");

$stmt->execute([$_SESSION['user_id']]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test Results - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/results.css">
</head>
<body>
    <div class="container">
        <h2>My Test Results</h2>
        
        <?php if ($results): ?>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Test Name</th>
                        <th>Description</th>
                        <th>Result Date</th>
                        <th>Status</th>
                        <th>Interpretation</th>
                        <th>Report</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                        <tr class="status-<?= strtolower($result['status']) ?>">
                            <td><?= htmlspecialchars($result['test_name'] ?? '') ?></td>
                            <td><?= htmlspecialchars($result['test_description'] ?? '') ?></td>
                            <td><?= htmlspecialchars($result['result_date'] ?? 'Pending') ?></td>
                            <td>
                                <span class="status-badge <?= strtolower($result['result_status']) ?>">
                                    <?= htmlspecialchars($result['result_status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($result['interpretation']): ?>
                                    <div class="interpretation">
                                        <?= nl2br(htmlspecialchars($result['interpretation'])) ?>
                                    </div>
                                <?php else: ?>
                                    <span class="pending">Pending Results</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($result['report_url']) && $result['status'] === 'completed'): ?>
                                    <a href="../../uploads/<?= htmlspecialchars($result['report_url']) ?>"
                                    class="btn btn-primary" target="_blank">
                                        View Report
                                    </a>
                                <?php else: ?>
                                    <span class="pending">Not Available</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-results">No test results available yet.</p>
        <?php endif; ?>
        
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
