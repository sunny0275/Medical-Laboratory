<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'patient') {
    header('Location: ../login.php');
    exit();
}

$file_path = filter_input(INPUT_GET, 'file', FILTER_SANITIZE_STRING);
if (!$file_path) {
    die('Invalid file path');
}

// Convert URL path to system path
$system_path = '../../uploads' . $file_path;

// Verify file exists
if (!file_exists($system_path)) {
    die('File not found');
}

// Set headers for PDF download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
header('Content-Length: ' . filesize($system_path));

// Output file
readfile($system_path);
exit();
