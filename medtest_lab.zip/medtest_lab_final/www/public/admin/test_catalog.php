<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$tests = $conn->query("
    SELECT 
        test_code,
        name,
        description,
        cost
    FROM test_catalog
    ORDER BY name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test Catalog Management - MedTest Lab</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="admin-panel">
        <div class="header-actions">
            <h1>Test Catalog Management</h1>
            <a href="add_test.php" class="btn">Add New Test</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Test Code</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Cost</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tests as $test): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($test['test_code']); ?></td>
                        <td><?php echo htmlspecialchars($test['name']); ?></td>
                        <td><?php echo htmlspecialchars($test['description']); ?></td>
                        <td>$<?php echo htmlspecialchars(number_format($test['cost'], 2)); ?></td>
                        <td>
                            <a href="edit_test.php?code=<?php echo urlencode($test['test_code']); ?>" class="btn">Edit</a>
                            <a href="delete_test.php?code=<?php echo urlencode($test['test_code']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
