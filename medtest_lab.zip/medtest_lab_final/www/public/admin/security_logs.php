<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$logs = $conn->query("
    SELECT 
        ql.id,
        ql.query_time,
        ql.query_text,
        ql.user_id,
        ql.suspicious,
        u.username,
        al.alert_message
    FROM query_log ql
    LEFT JOIN users u ON ql.user_id = u.id
    LEFT JOIN alert_log al ON ql.id = al.query_id
    ORDER BY ql.query_time DESC
    LIMIT 100
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Security Logs - MedTest Lab</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="admin-panel">
        <h1>Security Logs</h1>
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>User</th>
                    <th>Query</th>
                    <th>Suspicious</th>
                    <th>Alert</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr class="<?php echo $log['suspicious'] ? 'suspicious' : ''; ?>">
                        <td><?php echo htmlspecialchars($log['query_time'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($log['username'] ?? 'Unknown User'); ?></td>
                        <td><?php echo htmlspecialchars($log['query_text'] ?? ''); ?></td>
                        <td><?php echo $log['suspicious'] ? 'Yes' : 'No'; ?></td>
                        <td><?php echo htmlspecialchars($log['alert_message'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
