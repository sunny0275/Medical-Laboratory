<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$staff = $conn->query("
    SELECT 
        s.staff_id,
        COALESCE(decrypt_data(s.name, u.role), '') as name,
        s.role,
        COALESCE(decrypt_data(s.contact_info, u.role), '') as contact_info,
        s.created_at,
        u.username
    FROM staff s
    JOIN users u ON s.userid = u.id
    ORDER BY s.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Management - MedTest Lab</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="admin-panel">

        <div class="header-actions">
            <h1>Staff Management</h1>
            <a href="add_staff.php" class="btn">Add New Staff</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Role</th>

                    <th>Contact Info</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($staff as $member): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($member['staff_id']); ?></td>
                        <td><?php echo htmlspecialchars($member['name']); ?></td>
                        <td><?php echo htmlspecialchars($member['username']); ?></td>
                        <td><?php echo htmlspecialchars($member['role']); ?></td>

                        <td><?php echo htmlspecialchars($member['contact_info']); ?></td>
                        <td><?php echo htmlspecialchars($member['created_at']); ?></td>
                        <td>


                            <a href="edit_staff.php?id=<?php echo $member['staff_id']; ?>" class="btn">Edit</a>
                            <a href="delete_staff.php?id=<?php echo $member['staff_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
