<div class="sidebar">
    <div class="user-info">
        <?php
        $conn = get_db_connection();
        $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $username = $stmt->fetchColumn();
        ?>
        <h3><?php echo htmlspecialchars($username); ?></h3>
        <span class="role"><?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Guest'; ?></span>
    </div>
    
    <nav class="nav-menu">
        <a href="/dashboard.php" class="nav-item">
            <i class="fas fa-home"></i>Dashboard
        </a>
        
        </a>
        <a href="/logout.php" class="nav-item logout">
            <i class="fas fa-sign-out-alt"></i>Logout
        </a>
    </nav>
</div>
