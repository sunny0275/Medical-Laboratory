<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars(trim($_POST['username']));
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);    
    $password = $_POST['password'];
    $name = htmlspecialchars(trim($_POST['name']));
    $dob = htmlspecialchars(trim($_POST['date_of_birth']));
    $contact = json_encode([
        'phone' => htmlspecialchars(trim($_POST['phone'])),
        'address' => htmlspecialchars(trim($_POST['address']))
    ]);
    $insurance = json_encode([
        'provider' => htmlspecialchars(trim($_POST['insurance_provider'])),
        'policy' => htmlspecialchars(trim($_POST['policy_number']))
    ]);

    $conn = get_db_connection();
    try {
        $conn->beginTransaction();

        // Insert into users table
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, encrypt_data(?, 'patient'), encrypt_data(?, 'patient'), 'patient')");
        $stmt->execute([$username, $email, $password]);
        $userId = $conn->lastInsertId();

        // Insert into patients table
        $stmt = $conn->prepare("INSERT INTO patients (userid, name, date_of_birth, contact_info, insurance_details, username, password) 
                               VALUES (?, encrypt_data(?, 'patient'), encrypt_data(?, 'patient'), 
                                      encrypt_data(?, 'patient'), encrypt_data(?, 'patient'),
                                      encrypt_data(?, 'patient'), encrypt_data(?, 'patient'))");
        $stmt->execute([$userId, $name, $dob, $contact, $insurance, $username, $password]);

        $conn->commit();
        header('Location: login.php');
        exit();
    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "Registration failed. Username may already exist.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/common.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
    <nav class="nav">
        <div class="logo">MedTest Lab</div>
        <a href="index.php">Home</a>
    </nav>

    <div class="form-container">
        <h2>Create Account</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
       
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="date_of_birth">Date of Birth</label>
                <input type="date" id="date_of_birth" name="date_of_birth" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" required>
            </div>

            <div class="form-group">
                <label for="insurance_provider">Insurance Provider</label>
                <input type="text" id="insurance_provider" name="insurance_provider" required>
            </div>

            <div class="form-group">
                <label for="policy_number">Policy Number</label>
                <input type="text" id="policy_number" name="policy_number" required>
            </div>

            <button type="submit" class="btn btn-primary">Register</button>
        </form>
       
        <p class="form-footer">
            Already have an account? <a href="login.php">Login here</a>
        </p>
    </div>
</body>
</html>
