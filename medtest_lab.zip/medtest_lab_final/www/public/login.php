<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';
require_once '../includes/Logger.php';
require_once '../includes/SecurityMonitor.php';

$securityMonitor = new SecurityMonitor();
$ip = $_SERVER['REMOTE_ADDR'];
$isBlocked = !$securityMonitor->checkIpStatus($ip);

if ($isBlocked) {
    $error = 'Your IP has been blocked for suspicious activity. Please try again later.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isBlocked) {
    $username = filter_input(INPUT_POST, 'username', FILTER_UNSAFE_RAW);
    $username = trim(strip_tags($username));
    $password = $_POST['password'];
    
    $logger = new Logger();
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    
    $sqlInjectionPatterns = [
        '/union\s+select/i',
        '/\/\*.*\*\//i',  
        '/\/\*.*/i',    
        '/\*\/.*/i',
        '/\'\s*or\s*[\'"]?[0-9a-zA-Z]+[\'"]?\s*=\s*[\'"]?[0-9a-zA-Z]+/i',
        '/or\s+true/i',
        '/;\s*drop\s+table/i',
        '/--/i',
        '/\'\s*or\s*\'.*\'\s*=\s*\'.*\'/i',
        '/\*\*\//i',
        '/union/i',
        '/select/i',
        '/drop/i',
        '/delete/i',
        '/update/i',
        '/insert/i',
        '/alter/i',
        '/create/i',
        '/exec/i',
        '/execute/i'
    ];

    foreach ($sqlInjectionPatterns as $pattern) {
        if (preg_match($pattern, $username) || preg_match($pattern, $password)) {
            $logger->logSecurityEvent('SQLi_ATTEMPT', [
                'ip' => $ip,
                'username' => $username,
                'user_agent' => $userAgent
            ]);
            echo "<script>alert('Access Denied - Security Alert Triggered'); window.location.href='login.php';</script>";
            exit();
        }
    }

    $failedAttempts = isset($_SESSION['failed_attempts'][$ip]) ? $_SESSION['failed_attempts'][$ip] : 0;
    
    $conn = get_db_connection();
    $stmt = $conn->prepare("SELECT id, decrypt_data(password, role) as password, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && $password === $user['password']) {
        $logger->logSecurityEvent('LOGIN_SUCCESS', [
            'user_id' => $user['id'],
            'ip' => $ip,
            'user_agent' => $userAgent
        ]);
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        unset($_SESSION['failed_attempts'][$ip]);
        header('Location: dashboard.php');
        exit();
    } else {
        $failedAttempts++;
        $_SESSION['failed_attempts'][$ip] = $failedAttempts;
        
        $logger->logSecurityEvent('LOGIN_FAILURE', [
            'ip' => $ip,
            'attempted_username' => $username,
            'user_agent' => $userAgent,
            'attempt_count' => $failedAttempts
        ]);

        if ($failedAttempts >= 5) {
            $logger->logSecurityEvent('ACCOUNT_LOCKOUT', [
                'ip' => $ip,
                'attempted_username' => $username
            ]);
            $error = "Account temporarily locked. Please try again later.";
        } else {
            $error = "Invalid credentials";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/common.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
    <nav class="nav">
        <div class="logo">MedTest Lab</div>
        <a href="index.php">Home</a>
    </nav>

    <div class="form-container">
        <h2>Login</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        
        <p class="form-footer">
            Don't have an account? <a href="register.php">Register here</a>
        </p>
    </div>
</body>
</html>
