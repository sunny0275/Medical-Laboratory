<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'lab_staff') {
    header('Location: ../login.php');
    exit();
}

$order_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$order_id) {
    header('Location: process_tests.php');
    exit();
}

$conn = get_db_connection();

// Get test information first
$stmt = $conn->prepare("
    SELECT
        o.order_id,
        o.patient_id,
        tc.name as test_name,
        tc.description as test_description,
        tc.test_code,
        o.status,
        DATE_FORMAT(o.order_date, '%Y-%m-%d %H:%i') as order_date,
        COALESCE(decrypt_data(p.name, 'patient'), '') as patient_name
    FROM orders o
    JOIN test_catalog tc ON o.test_code = tc.test_code
    JOIN patients p ON o.patient_id = p.patient_id
    WHERE o.order_id = ?
");
$stmt->execute([$order_id]);
$test = $stmt->fetch(PDO::FETCH_ASSOC);

// Then handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $interpretation = trim($_POST['interpretation'] ?? '');
    
    $upload_dir = '../../uploads/reports/' . date('Y/m/d/');
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    if (isset($_FILES['report_pdf']) && $_FILES['report_pdf']['error'] === UPLOAD_ERR_OK) {
        $file_extension = pathinfo($_FILES['report_pdf']['name'], PATHINFO_EXTENSION);
        if ($file_extension === 'pdf') {
            // Generate filename with timestamp and microseconds for uniqueness
            $timestamp = microtime(true);
            $micro = sprintf("%06d", ($timestamp - floor($timestamp)) * 1000000);
            $filename = sprintf(
                '%s_Order%s_P%s_%s_%s_%s.%s',
                str_replace(' ', '_', strtoupper($test['test_name'])),
                str_pad((string)$test['order_id'], 6, '0', STR_PAD_LEFT),
                str_pad((string)$test['patient_id'], 6, '0', STR_PAD_LEFT),
                date('YmdHis'),
                $micro,
                bin2hex(random_bytes(4)),
                $file_extension
            );
        
            $file_path = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['report_pdf']['tmp_name'], $file_path)) {
                $report_url = 'reports/' . date('Y/m/d/') . $filename;
                
                // Start transaction
                $conn->beginTransaction();
                
                try {
                    // Insert result
                    $stmt = $conn->prepare("
                        INSERT INTO results (order_id, interpretation, report_url, staff_id)
                        VALUES (?, encrypt_data(?, (SELECT role FROM users WHERE id = ?)), 
                                  encrypt_data(?, (SELECT role FROM users WHERE id = ?)), ?)
                    ");
                    
                    $stmt->execute([
                        $order_id, 
                        $interpretation, 
                        $_SESSION['user_id'],
                        $report_url, 
                        $_SESSION['user_id'],
                        $_SESSION['user_id']
                    ]);

                    // Update order status
                    $stmt = $conn->prepare("
                        UPDATE orders 
                        SET status = 'completed', 
                            staff_id = ? 
                        WHERE order_id = ?
                    ");
                    $stmt->execute([$_SESSION['user_id'], $order_id]);

                    $conn->commit();
                    header('Location: ../dashboard.php?success=1');
                    exit();
                } catch (Exception $e) {
                    $conn->rollBack();
                    $error = "Failed to save test results";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Record Test Result - MedTest Lab</title>
    <link rel="stylesheet" href="/assets/css/common.css">
    <link rel="stylesheet" href="/assets/css/record_result.css">
</head>
<body>
    <div class="container">
        <h1>Record Test Result</h1>
        
        <div class="test-info">
            <h3>Test Details</h3>
            <div class="info-grid">
                <div class="info-item">
                    <label>Order ID:</label>
                    <span><?= htmlspecialchars($test['order_id']) ?></span>
                </div>
                <div class="info-item">
                    <label>Patient Name:</label>
                    <span><?= htmlspecialchars($test['patient_name']) ?></span>
                </div>
                <div class="info-item">
                    <label>Test Name:</label>
                    <span><?= htmlspecialchars($test['test_name']) ?></span>
                </div>
                <div class="info-item">
                    <label>Order Date:</label>
                    <span><?= htmlspecialchars($test['order_date']) ?></span>
                </div>
            </div>
            
            <div class="test-description">
                <h4>Test Description:</h4>
                <p><?= htmlspecialchars($test['test_description']) ?></p>
            </div>
        </div>
        
        <form method="POST" action="" class="result-form" enctype="multipart/form-data">
            <div class="form-group">
                <label for="interpretation">Test Interpretation</label>
                <textarea id="interpretation" name="interpretation" required 
                          placeholder="Enter detailed test interpretation and findings..."></textarea>
            </div>
            
            <div class="form-group">
                <label for="report_pdf">Upload Report PDF</label>
                <input type="file" id="report_pdf" name="report_pdf" accept=".pdf" required>
                <small class="file-help">Please upload the test report in PDF format</small>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn btn-primary">Submit Result</button>
                <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </form>
    </div>
</body>
</html>
