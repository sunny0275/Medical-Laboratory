<?php
require_once '../../includes/auth.php';
require_once '../../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'lab_staff') {
    header('Location: ../login.php');
    exit();
}

$conn = get_db_connection();
$pending_tests = $conn->query("
    SELECT 
        o.order_id,
        tc.name as test_name,
        tc.test_code,
        o.status,
        DATE_FORMAT(o.order_date, '%Y-%m-%d %H:%i') as order_date
    FROM orders o
    JOIN test_catalog tc ON o.test_code = tc.test_code
    WHERE o.status IN ('pending', 'sampling')
    ORDER BY o.order_date ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Process Tests - MedTest Lab</title>
    <link rel="stylesheet" href="../assets/css/process_tests.css">
</head>
<body>
    <div class="lab-panel">
        <div class="header-actions">
            <h1>Process Tests</h1>
            <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Test Name</th>
                    <th>Status</th>
                    <th>Order Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pending_tests as $test): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($test['order_id']); ?></td>
                        <td><?php echo htmlspecialchars($test['test_name']); ?></td>
                        <td><?php echo htmlspecialchars($test['status']); ?></td>
                        <td><?php echo htmlspecialchars($test['order_date']); ?></td>
                        <td>
                            <a href="record_result.php?id=<?php echo $test['order_id']; ?>" class="btn">Record Result</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
