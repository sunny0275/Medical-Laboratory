<?php
session_start();
require_once '../includes/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedTest Lab - Welcome</title>
    <link rel="stylesheet" href="/assets/css/common.css">
    <link rel="stylesheet" href="/assets/css/index.css">
</head>
<body>
    <nav class="nav">
        <div class="logo">MedTest Lab</div>
        <div class="nav-links">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php" class="btn btn-primary">Dashboard</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary">Login</a>
                <a href="register.php" class="btn btn-secondary">Register</a>
            <?php endif; ?>
        </div>
    </nav>

    <section class="hero">
        <h1>Welcome to MedTest Lab</h1>
        <p>Your Trusted Partner in Medical Testing</p>
        <div class="hero-buttons">
            <a href="register.php" class="btn btn-secondary">Get Started</a>
        </div>
    </section>

    <section class="features">
        <div class="feature-card">
            <h3>Lab Tests</h3>
            <p>Comprehensive range of medical tests</p>
        </div>
        <div class="feature-card">
            <h3>Online Results</h3>
            <p>Access your test results securely</p>
        </div>
        <div class="feature-card">
            <h3>Expert Staff</h3>
            <p>Qualified medical professionals</p>
        </div>
    </section>


</body>
</html>
