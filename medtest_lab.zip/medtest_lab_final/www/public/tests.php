<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';

if (!check_auth() || $_SESSION['role'] !== 'lab_staff') {
    header('Location: login.php');
    exit();
}

$conn = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $order_id = $_POST['order_id'];
    $result_data = $_POST['result_data'];
    $interpretation = $_POST['interpretation'];
    $stmt = $conn->prepare("
        INSERT INTO test_results (
            result_id,
            order_id,
            result_data,
            interpretation,
            pathologist_id
        ) VALUES (
            CONCAT('RES', LPAD(LAST_INSERT_ID() + 1, 3, '0')),
            ?,
            encrypt_data(?, 'lab_staff'),
            encrypt_data(?, 'lab_staff'),
            ?
        )
    ");
    
    $stmt->execute([$order_id, $result_data, $interpretation, $_SESSION['user_id']]);
    
    // Update order status
    $stmt = $conn->prepare("UPDATE test_orders SET status = 'completed' WHERE order_id = ?");
    $stmt->execute([$order_id]);
    
    header('Location: dashboard.php?success=1');
    exit();
}

// Get test details if order_id is provided
if (isset($_GET['order_id'])) {
    $stmt = $conn->prepare("
        SELECT 
            t.*,
            tc.name as test_name,
            decrypt_data(pd.name, 'lab_staff') as patient_name
        FROM test_orders t
        JOIN test_catalog tc ON t.test_id = tc.id
        JOIN patient_data pd ON t.patient_id = pd.user_id
        WHERE t.order_id = ?
    ");
    $stmt->execute([$_GET['order_id']]);
    $test = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Record Test Results</title>
    <link rel="stylesheet" href="/assets/css/common.css">
</head>
<body>
    <div class="container">
        <h2>Record Test Results</h2>
        <form method="POST" class="form">
            <input type="hidden" name="order_id" value="<?php echo $test['order_id']; ?>">
            
            <div class="form-group">
                <label>Patient: <?php echo htmlspecialchars($test['patient_name']); ?></label>
            </div>

            <div class="form-group">
                <label>Test: <?php echo htmlspecialchars($test['test_name']); ?></label>
            </div>
            
            <div class="form-group">
                <label for="result_data">Test Results</label>
                <textarea name="result_data" required rows="4"></textarea>
            </div>
            
            <div class="form-group">
                <label for="interpretation">Interpretation</label>
                <textarea name="interpretation" required rows="2"></textarea>
            </div>
            
            <button type="submit" class="btn">Save Results</button>
        </form>
    </div>
</body>
</html>
