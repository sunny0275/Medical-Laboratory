<?php
class Database {
    private $conn;
    private $queryMonitor;

    public function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=db;dbname=medtest",
                "app_user",
                "userpass",
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $this->queryMonitor = new QueryMonitor($this->conn);
        } catch(PDOException $e) {
            throw new Exception("Connection failed: " . $e->getMessage());
        }
    }

    public function executeQuery($query, $params = [], $userId = null) {
        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        $this->queryMonitor->logQuery($query, $userId);
        return $stmt;
    }

    public function encryptData($data) {
        $stmt = $this->conn->prepare("SELECT AES_ENCRYPT(?, @key_str) as encrypted");
        $stmt->execute([$data]);
        return $stmt->fetch(PDO::FETCH_ASSOC)['encrypted'];
    }

    public function decryptData($data) {
        $stmt = $this->conn->prepare("SELECT AES_DECRYPT(?, @key_str) as decrypted");
        $stmt->execute([$data]);
        return $stmt->fetch(PDO::FETCH_ASSOC)['decrypted'];
    }
}
