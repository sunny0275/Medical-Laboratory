<?php
class QueryMonitor {
    private $logFile = '/var/log/mysql/query.log';
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function logQuery($query, $userId) {
        $suspicious = $this->detectSuspiciousPattern($query);
        
        $stmt = $this->conn->prepare("
            INSERT INTO query_log (query_text, user_id, suspicious) 
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([$query, $userId, $suspicious]);

        if ($suspicious) {
            $this->generateAlert($query, $userId);
        }
    }

    private function detectSuspiciousPattern($query) {
        $patterns = [
            '/UNION/i',
            '/OR.*=.*/',
            '/DROP/i',
            '/;.*/',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $query)) {
                return true;
            }
        }
        return false;
    }

    private function generateAlert($query, $userId) {
        $alert = date('Y-m-d H:i:s') . " - Suspicious query detected:\n";
        $alert .= "User ID: $userId\n";
        $alert .= "Query: $query\n";
        
        file_put_contents('/var/log/mysql/alerts.log', $alert, FILE_APPEND);
    }
}
