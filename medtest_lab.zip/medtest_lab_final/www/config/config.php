<?php
// Database configuration
define('DB_HOST', 'db');
define('DB_NAME', 'medtest');
define('DB_USER', 'root');
define('DB_PASS', 'rootpassword');

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
