<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';
class Logger {
    private $logFile = __DIR__ . '/../logs/security.log';
    
    public function logSecurityEvent($eventType, $data) {
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = [
            'timestamp' => $timestamp,
            'event_type' => $eventType,
            'data' => $data
        ];
        
        file_put_contents(
            $this->logFile, 
            json_encode($logEntry) . "\n", 
            FILE_APPEND
        );
        
        // Send alerts for critical events
        if (in_array($eventType, ['SQLi_ATTEMPT', 'ACCOUNT_LOCKOUT'])) {
            $this->sendAlert($logEntry);
        }
    }
    
    private function sendAlert($logEntry) {
        // Implement alert mechanism (email, SMS, Slack, etc.)
        // Example: mail('admin@medtest.com', 'Security Alert', json_encode($logEntry));
    }
}
