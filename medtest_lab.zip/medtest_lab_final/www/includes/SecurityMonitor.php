<?php
class SecurityMonitor {
    private $logFile = __DIR__ . '/../logs/security.log';
    private $blockListFile = __DIR__ . '/../logs/blocked_ips.json';
    private $maxAttempts = 2;
    private $blockDuration = 60; // 60 seconds

    public function checkIpStatus($ip) {
        $blockedIps = $this->getBlockedIps();
        $currentTime = time();
        
        if (isset($blockedIps[$ip])) {
            if ($currentTime >= $blockedIps[$ip]) {
                // Block expired - reset everything
                unset($blockedIps[$ip]);
                $this->saveBlockedIps($blockedIps);
                $this->resetAttemptsCount($ip);
                return true;
            }
            return false; // Still blocked  
        }
        
        $suspiciousAttempts = $this->countRecentSuspiciousAttempts($ip);
        if ($suspiciousAttempts >= $this->maxAttempts) {
            $this->blockIp($ip);
            return false;
        }
        
        return true;
    }

    private function resetAttemptsCount($ip) {
        $oneHourAgo = time() - $this->blockDuration;
        $logs = file_get_contents($this->logFile);
        $lines = array_filter(explode("\n", trim($logs)), function($line) use ($ip, $oneHourAgo) {
            $log = json_decode($line, true);
            return !($log && 
                    $log['data']['ip'] === $ip && 
                    strtotime($log['timestamp']) <= $oneHourAgo);
        });
        file_put_contents($this->logFile, implode("\n", $lines) . "\n");
    }

    private function cleanExpiredBlocks(&$blockedIps) {
        $currentTime = time();
        foreach ($blockedIps as $ip => $blockTime) {
            if ($currentTime >= $blockTime) {
                unset($blockedIps[$ip]);
            }
        }
        $this->saveBlockedIps($blockedIps);
    }

    private function countRecentSuspiciousAttempts($ip) {
        $count = 0;
            $oneHourAgo = time() - 3600;
        
            $logs = file_get_contents($this->logFile);
            $lines = explode("\n", trim($logs));
        
            foreach ($lines as $line) {
                $log = json_decode($line, true);
                if (!$log || !isset($log['data']['ip'])) continue;
            
                // Get event type safely using null coalescing operator
                $eventType = $log['event_type'] ?? $log['event'] ?? '';
            
                // Check if this IP has suspicious activity
                if ($log['data']['ip'] === $ip && 
                    in_array($eventType, ['SQLi_ATTEMPT', 'LOGIN_FAILURE']) && 
                    strtotime($log['timestamp']) > $oneHourAgo) {
                    $count++;
                }
            }
        
            return $count;
        }
    private function blockIp($ip) {
        $blockedIps = $this->getBlockedIps();
        $blockedIps[$ip] = time() + $this->blockDuration;
        $this->saveBlockedIps($blockedIps);
    }

    private function getBlockedIps() {
        if (!file_exists($this->blockListFile)) {
            return [];
        }
        return json_decode(file_get_contents($this->blockListFile), true) ?? [];
    }

    private function saveBlockedIps($blockedIps) {
        file_put_contents($this->blockListFile, json_encode($blockedIps));
    }
}
