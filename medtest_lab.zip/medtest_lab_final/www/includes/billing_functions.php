<?php
function createBilling($conn, $order_id, $amount, $created_by) {
    $stmt = $conn->prepare("
        INSERT INTO billing (
            billing_id,
            order_id,
            amount,
            payment_status,
            insurance_claim_status,
            created_by
        ) VALUES (
            UUID(),
            ?,
            ?,
            'pending',
            'not_submitted',
            ?
        )
    ");
    return $stmt->execute([$order_id, $amount, $created_by]);
}

function updatePaymentStatus($conn, $billing_id, $status) {
    $stmt = $conn->prepare("
        UPDATE billing 
        SET payment_status = ? 
        WHERE billing_id = ?
    ");
    return $stmt->execute([$status, $billing_id]);
}

function getPendingPayments($conn) {
    return $conn->query("
        SELECT 
            b.billing_id,
            b.order_id,
            COALESCE(decrypt_data(p.name, (SELECT role FROM users WHERE id = p.userid)), '') as patient_name,
            tc.name as test_name,
            b.amount,
            b.payment_status,
            b.insurance_claim_status
        FROM billing b
        JOIN orders o ON b.order_id = o.order_id
        JOIN patients p ON o.patient_id = p.patient_id
        JOIN test_catalog tc ON o.test_code = tc.test_code
        WHERE b.payment_status = 'pending'
        ORDER BY b.billing_id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
}
