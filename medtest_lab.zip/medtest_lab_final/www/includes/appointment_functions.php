<?php
function createAppointment($conn, $order_id, $appointment_date, $notes, $created_by) {
    $stmt = $conn->prepare("
        INSERT INTO appointments (
            appointment_id,
            order_id,
            appointment_date,
            status,
            notes,
            created_by
        ) VALUES (
            UUID(),
            ?,
            ?,
            'scheduled',
            encrypt_data(?, 'secretary'),
            ?
        )
    ");
    return $stmt->execute([$order_id, $appointment_date, $notes, $created_by]);
}

function getUpcomingAppointments($conn) {
    return $conn->query("
        SELECT 
            a.appointment_id,
            decrypt_data(pd.name, 'secretary') as patient_name,
            decrypt_data(pd.phone, 'secretary') as contact,
            tc.name as test_name,
            a.appointment_date,
            a.status,
            b.payment_status
        FROM appointments a
        JOIN test_orders o ON a.order_id = o.order_id
        JOIN patient_data pd ON o.patient_id = pd.user_id
        JOIN test_catalog tc ON o.test_id = tc.id
        LEFT JOIN billing b ON o.order_id = b.order_id
        WHERE a.appointment_date >= CURDATE()
        ORDER BY a.appointment_date ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
}
