<?php
function get_db_connection() {
    static $conn = null;
    if ($conn === null) {
        $host = 'db';
        $retries = 5;
        $delay = 2;

        while ($retries > 0) {
            try {
                $conn = new PDO(
                    "mysql:host=$host;dbname=medtest;charset=utf8mb4",
                    "medtest_user",
                    "userpassword",
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                    ]
                );
                break;
            } catch (PDOException $e) {
                $retries--;
                if ($retries <= 0) {
                    die("Connection failed: " . $e->getMessage());
                }
                sleep($delay);
            }
        }
    }
    return $conn;
}
