<?php
$users = [
    ['username' => 'admin', 'password' => 'admin123', 'role' => 'admin'],
    ['username' => 'labstaff', 'password' => 'staff123', 'role' => 'lab_staff'],
    ['username' => 'secretary', 'password' => 'sec123', 'role' => 'secretary'],
    ['username' => 'patient', 'password' => 'pat123', 'role' => 'patient']
];

foreach ($users as $user) {
    $hash = password_hash($user['password'], PASSWORD_DEFAULT);
    echo "Username: {$user['username']}\n";
    echo "Password Hash: {$hash}\n";
    echo "Role: {$user['role']}\n";
    echo "SQL: INSERT INTO users (username, password_hash, role) VALUES ('{$user['username']}', '{$hash}', '{$user['role']}');\n\n";
}
