-- Encryption the database
SET GLOBAL innodb_file_per_table=ON;
CREATE DATABASE IF NOT EXISTS medtest ENCRYPTION='Y';
USE medtest;

DROP FUNCTION IF EXISTS encrypt_data;
DROP FUNCTION IF EXISTS decrypt_data;

DROP TABLE IF EXISTS alert_log;
DROP TABLE IF EXISTS query_log;
DROP TABLE IF EXISTS billing;
DROP TABLE IF EXISTS results;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS test_catalog;
DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS role_keys;
DROP TABLE IF EXISTS encryption_keys;


CREATE TABLE encryption_keys (
    id INT PRIMARY KEY AUTO_INCREMENT,
    key_value VARBINARY(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE
) ENCRYPTION = 'Y';

CREATE TABLE role_keys (
    role_id VARCHAR(50) UNIQUE,
    key_id INT,
    FOREIGN KEY (key_id) REFERENCES encryption_keys(id)
) ENCRYPTION = 'Y';

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARBINARY(100)NOT NULL UNIQUE,
    password VARBINARY(255) NOT NULL,
    role ENUM('admin', 'lab_staff', 'secretary', 'patient') NOT NULL DEFAULT 'patient',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENCRYPTION = 'Y';

CREATE TABLE patients (
    patient_id INT PRIMARY KEY AUTO_INCREMENT PRIMARY KEY,
    userid INT ,
    name VARBINARY(100),
    date_of_birth VARBINARY(100),
    contact_info VARBINARY(255),
    insurance_details VARBINARY(255),
    username VARBINARY(50) UNIQUE,
    password VARBINARY(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userid) REFERENCES users(id)
) ENCRYPTION = 'Y';

CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    userid INT UNIQUE,
    name VARCHAR(100),
    role ENUM('doctor', 'pathologist', 'physician','lab_technician', 'secretary', 'admin'),
    contact_info VARBINARY(255),
    username VARBINARY(50) UNIQUE,
    password VARBINARY(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userid) REFERENCES users(id)
) ENCRYPTION = 'Y';

CREATE TABLE test_catalog (
    test_code VARCHAR(50) UNIQUE,
    name VARCHAR(100),
    description TEXT,
    cost DECIMAL(10,2)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT(50),
    test_code VARCHAR(20),
    staff_id INT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'sampling', 'testing', 'completed', 'cancelled'),
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (test_code) REFERENCES test_catalog(test_code),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
) ENCRYPTION = 'Y';

CREATE TABLE appointments (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    appointment_date DATETIME,
    status ENUM('scheduled', 'completed', 'cancelled'), 
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
); 

CREATE TABLE results (
    result_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    report_url VARBINARY(255),
    interpretation VARBINARY(255),
    staff_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
) ENCRYPTION = 'Y';


CREATE TABLE billing (
    billing_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT(50),
    amount DECIMAL(10,2),
    payment_status ENUM('pending', 'paid', 'cancelled','compeleted','rejected'),
    payment_method ENUM('Cash', 'Credit_card', 'Alipay', 'WeChat', 'PayPal'),
    insurance_claim_status ENUM('not_submitted', 'pending', 'completed', 'rejected', 'submitted', 'paid'),
    payment_date TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
) ENCRYPTION = 'Y';


CREATE TABLE query_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    query_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    query_text TEXT,
    user_id INT,
    suspicious BOOLEAN DEFAULT FALSE
);

CREATE TABLE alert_log (
    query_id INT,
    alert_message TEXT,
    FOREIGN KEY (query_id) REFERENCES query_log(id)
);
