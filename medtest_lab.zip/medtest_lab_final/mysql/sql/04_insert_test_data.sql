-- Insert users first
INSERT INTO users (username, email, password, role) VALUES
('admin1', encrypt_data('admin@medtest.com', 'admin'), encrypt_data('1234', 'admin'), 'admin'),
('lab_staff1', encrypt_data('lab_staff1@medtest.com', 'lab_staff'), encrypt_data('1234', 'lab_staff'), 'lab_staff'),
('lab_staff2', encrypt_data('lab_staff2@medtest.com', 'lab_staff'), encrypt_data('1234', 'lab_staff'), 'lab_staff'),
('lab_staff3', encrypt_data('lab_staff3@medtest.com', 'lab_staff'), encrypt_data('1234', 'lab_staff'), 'lab_staff'),
('lab_staff4', encrypt_data('lab_staff4@medtest.com', 'lab_staff'), encrypt_data('1234', 'lab_staff'), 'lab_staff'),
('patient1', encrypt_data('patient1@example.com', 'patient'), encrypt_data('1234', 'patient'), 'patient'),
('patient2', encrypt_data('patient2@example.com', 'patient'), encrypt_data('1234', 'patient'), 'patient'),
('patient3', encrypt_data('patient3@example.com', 'patient'), encrypt_data('1234', 'patient'), 'patient'),
('patient4', encrypt_data('patient4@example.com', 'patient'), encrypt_data('1234', 'patient'), 'patient'),
('secretary1', encrypt_data('secretary1@medtest.com', 'secretary'), encrypt_data('1234', 'secretary'), 'secretary');

-- Insert patients using user references
INSERT INTO patients (userid, name, date_of_birth, contact_info, insurance_details, username, password)
SELECT u.id,
    encrypt_data('John Smith', 'patient'),
    encrypt_data('1985-03-15', 'patient'),
    encrypt_data('{"phone": "555-0101", "address": "123 Main St"}', 'patient'),
    encrypt_data('{"provider": "HealthCare Plus", "policy": "HC123456"}', 'patient'),
    encrypt_data('patient1', 'patient'),
    encrypt_data('1234', 'patient')
FROM users u WHERE u.username = 'patient1';

INSERT INTO patients (userid, name, date_of_birth, contact_info, insurance_details, username, password)
SELECT u.id,
    encrypt_data('Mary Johnson', 'patient'),
    encrypt_data('1990-07-22', 'patient'),
    encrypt_data('{"phone": "555-0102", "address": "456 Oak Ave"}', 'patient'),
    encrypt_data('{"provider": "MediCare", "policy": "MC789012"}', 'patient'),
    encrypt_data('patient2', 'patient'),
    encrypt_data('1234', 'patient')
FROM users u WHERE u.username = 'patient2';

INSERT INTO patients (userid, name, date_of_birth, contact_info, insurance_details, username, password)
SELECT u.id,
    encrypt_data('Sarah Wilson', 'patient'),
    encrypt_data('1988-06-25', 'patient'),
    encrypt_data('{"phone": "555-0103", "address": "789 Pine St"}', 'patient'),
    encrypt_data('{"provider": "BlueCross", "policy": "BC345678"}', 'patient'),
    encrypt_data('patient3', 'patient'),
    encrypt_data('1234', 'patient')
FROM users u WHERE u.username = 'patient3';

INSERT INTO patients (userid, name, date_of_birth, contact_info, insurance_details, username, password)
SELECT u.id,
    encrypt_data('Michael Brown', 'patient'),
    encrypt_data('1992-09-15', 'patient'),
    encrypt_data('{"phone": "555-0104", "address": "321 Elm St"}', 'patient'),
    encrypt_data('{"provider": "Aetna", "policy": "AE901234"}', 'patient'),
    encrypt_data('patient4', 'patient'),
    encrypt_data('1234', 'patient')
FROM users u WHERE u.username = 'patient4';

-- Insert staff using user references
INSERT INTO staff (userid, name, role, contact_info, username, password)
SELECT u.id,
    'Dr. Admin',
    'doctor',
    encrypt_data('{"phone": "555-0004", "department": "Administration"}', 'lab_staff'),
    encrypt_data('lab_staff1', 'lab_staff'),
    encrypt_data('1234', 'lab_staff')
FROM users u WHERE u.username = 'lab_staff1';

INSERT INTO staff (userid, name, role, contact_info, username, password)
SELECT u.id,
    'James Brown',
    'lab_technician',
    encrypt_data('{"phone": "555-0003", "department": "Laboratory"}', 'lab_staff'),
    encrypt_data('lab_staff2', 'lab_staff'),
    encrypt_data('1234', 'lab_staff')
FROM users u WHERE u.username = 'lab_staff2';

INSERT INTO staff (userid, name, role, contact_info, username, password)
SELECT u.id,
    'Dr. Sarah Connor',
    'pathologist',
    encrypt_data('{"phone": "555-0005", "department": "Pathology"}', 'lab_staff'),
    encrypt_data('lab_staff3', 'lab_staff'),
    encrypt_data('1234', 'lab_staff')
FROM users u WHERE u.username = 'lab_staff3';

INSERT INTO staff (userid, name, role, contact_info, username, password)
SELECT u.id,
    'Dr. John Carter',
    'physician',
    encrypt_data('{"phone": "555-0006", "department": "General"}', 'lab_staff'),
    encrypt_data('lab_staff4', 'lab_staff'),
    encrypt_data('1234', 'lab_staff')
FROM users u WHERE u.username = 'lab_staff4';

-- Insert test catalog
INSERT INTO test_catalog (test_code, name, description, cost) VALUES
('CBC001', 'Complete Blood Count', 'Comprehensive blood cell analysis', 75.00),
('LIPID001', 'Lipid Panel', 'Cholesterol and triglycerides test', 95.00),
('THYROID01', 'Thyroid Function', 'TSH, T3, and T4 analysis', 120.00),
('GLUC001', 'Glucose Test', 'Blood sugar level analysis', 45.00),
('VITD001', 'Vitamin D', '25-hydroxy vitamin D test', 85.00);

-- Insert orders with 1-2 samples per status
INSERT INTO orders (patient_id, test_code, staff_id, status)
SELECT
    p.patient_id,
    'CBC001',
    s.staff_id,
    'pending'
FROM
    (SELECT patient_id FROM patients WHERE decrypt_data(name, 'patient') = 'John Smith') p,
    (SELECT staff_id FROM staff WHERE name = 'Dr. Admin') s

UNION ALL

SELECT
    p.patient_id,
    'LIPID001',
    s.staff_id,
    'pending'
FROM
    (SELECT patient_id FROM patients WHERE decrypt_data(name, 'patient') = 'Mary Johnson') p,
    (SELECT staff_id FROM staff WHERE name = 'James Brown') s

UNION ALL

SELECT
    p.patient_id,
    'THYROID01',
    s.staff_id,
    'completed'
FROM
    (SELECT patient_id FROM patients WHERE decrypt_data(name, 'patient') = 'Sarah Wilson') p,
    (SELECT staff_id FROM staff WHERE name = 'Dr. Sarah Connor') s

UNION ALL

SELECT
    p.patient_id,
    'GLUC001',
    s.staff_id,
    'completed'
FROM
    (SELECT patient_id FROM patients WHERE decrypt_data(name, 'patient') = 'Michael Brown') p,
    (SELECT staff_id FROM staff WHERE name = 'Dr. John Carter') s;

-- Insert appointments with matching statuses
INSERT INTO appointments (order_id, appointment_date, status)
SELECT
    o.order_id,
    CASE o.status
        WHEN 'pending' THEN DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY) + INTERVAL '14:15' HOUR_MINUTE
        WHEN 'completed' THEN DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY) + INTERVAL '14:15' HOUR_MINUTE
    END as appointment_date,
    CASE o.status
        WHEN 'completed' THEN 'scheduled'
        WHEN 'completed' THEN 'completed'
    END as status
FROM orders o;

-- Insert results for completed orders
INSERT INTO results (order_id, report_url, interpretation, staff_id)
SELECT
    o.order_id,
    encrypt_data('/reports/2024/03/05/test01.pdf', 'lab_staff'),
    encrypt_data(
        CASE tc.test_code
            WHEN 'CBC' THEN 'COMPLETE BLOOD COUNT ANALYSIS
                White Blood Cell Count: 7.2 x 10^9/L (Normal: 4.0-11.0)
                Red Blood Cell Count: 4.8 x 10^12/L (Normal: 4.2-5.4)
                Hemoglobin: 14.2 g/dL (Normal: 13.0-17.0)
                Hematocrit: 42% (Normal: 38.8-50.0)
                Platelet Count: 250 x 10^9/L (Normal: 150-450)
                Assessment: All parameters within normal range.'
            WHEN 'GLUC' THEN 'GLUCOSE TOLERANCE TEST
                Fasting Glucose: 92 mg/dL (Normal: 70-100)
                2-Hour Glucose: 115 mg/dL (Normal: <140)
                HbA1c: 5.4% (Normal: 4.0-5.6)
                Assessment: Normal glucose metabolism.'
            WHEN 'LIPID' THEN 'LIPID PANEL RESULTS
                Total Cholesterol: 180 mg/dL (Normal: <200)
                HDL: 55 mg/dL (Normal: >40)
                LDL: 110 mg/dL (Normal: <130)
                Triglycerides: 150 mg/dL (Normal: <150)
                Assessment: Lipid profile within optimal ranges.'
            ELSE 'Test results within normal reference ranges.
                Detailed parameters available in attached report.'
        END,
        'lab_staff'
    ),
    o.staff_id
FROM orders o
JOIN test_catalog tc ON o.test_code = tc.test_code
WHERE o.status = 'completed';



-- Insert billing records
INSERT INTO billing (order_id, amount, payment_status, payment_method, insurance_claim_status, payment_date)
SELECT
    o.order_id,
    tc.cost,
    CASE o.status
        WHEN 'completed' THEN 'paid'
        ELSE 'paid'
    END as payment_status,
    CASE o.status
        WHEN 'completed' THEN 'Credit_card'
        ELSE NULL
    END as payment_method,
    CASE o.status
        WHEN 'completed' THEN 'completed'
        ELSE 'not_submitted'
    END as insurance_claim_status,
    CASE o.status
        WHEN 'completed' THEN DATE_SUB(CURRENT_TIMESTAMP, INTERVAL FLOOR(RAND() * 30) DAY)
        ELSE NULL
    END as payment_date
FROM orders o
JOIN test_catalog tc ON o.test_code = tc.test_code;

-- Insert query logs
INSERT INTO query_log (query_text, user_id, suspicious)
SELECT 
    query_text,
    u.id,
    suspicious
FROM users u
CROSS JOIN (
    SELECT 'SELECT * FROM patients' as query_text, FALSE as suspicious UNION ALL
    SELECT 'UPDATE test_results SET status = "completed"', FALSE UNION ALL
    SELECT 'DROP TABLE patients', TRUE UNION ALL
    SELECT 'DELETE FROM billing', TRUE
) queries
WHERE u.username IN ('admin1', 'lab_staff1', 'secretary1')
LIMIT 8;
