DELIMITER //
CREATE FUNCTION encrypt_data(data VARCHAR(255), user_role VARCHAR(50)) 
RETURNS VARBINARY(255)
DETERMINISTIC
BEGIN
    DECLARE role_key VARBINARY(255);
    DECLARE iv BINARY(16);
    SET iv = RANDOM_BYTES(16);
    
    SELECT ek.key_value INTO role_key 
    FROM encryption_keys ek 
    JOIN role_keys rk ON ek.id = rk.key_id 
    WHERE rk.role_id = user_role;
    
    RETURN CONCAT(iv, AES_ENCRYPT(data, SHA2(role_key, 256), iv));
END //
CREATE FUNCTION decrypt_data(encrypted_data VARBINARY(255), user_role VARCHAR(50)) 
RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE role_key VARBINARY(255);
    DECLARE iv BINARY(16);
    DECLARE actual_data VARBINARY(255);
    
    SET iv = LEFT(encrypted_data, 16);
    SET actual_data = SUBSTRING(encrypted_data, 17);
    
    SELECT ek.key_value INTO role_key 
    FROM encryption_keys ek 
    JOIN role_keys rk ON ek.id = rk.key_id 
    WHERE rk.role_id = user_role;
    
    RETURN AES_DECRYPT(actual_data, SHA2(role_key, 256), iv);
END //
DELIMITER ;