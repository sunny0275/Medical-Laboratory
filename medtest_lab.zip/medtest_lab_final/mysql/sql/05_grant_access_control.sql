USE medtest;

/* Admin user creation */
CREATE USER IF NOT EXISTS 'medtest_user'@'%' IDENTIFIED BY '1234';
GRANT ALL PRIVILEGES ON medtest.* TO 'medtest_user'@'%';

/* Create lab staff and secretary users */
CREATE USER IF NOT EXISTS 'medtest_labstaff'@'%' IDENTIFIED BY 'labstaffpassword';
CREATE USER IF NOT EXISTS 'medtest_secretary'@'%' IDENTIFIED BY 'secretarypassword';

/* Access for lab staff to input test data and check appointments */
GRANT SELECT ON medtest.appointments TO 'medtest_labstaff'@'%';
GRANT INSERT ON medtest.test_catalog TO 'medtest_labstaff'@'%';

/* Access for secretary to input appointments, read write billing and check results */
GRANT INSERT ON medtest.appointments TO 'medtest_secretary'@'%';
GRANT SELECT, UPDATE ON medtest.billing TO 'medtest_secretary'@'%';
GRANT SELECT ON medtest.results TO 'medtest_secretary'@'%';

/* For patient data, patient would ask secretary to insert */
GRANT INSERT ON medtest.patients TO 'medtest_secretary'@'%';

FLUSH PRIVILEGES;
