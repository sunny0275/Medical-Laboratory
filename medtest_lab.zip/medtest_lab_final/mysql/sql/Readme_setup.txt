First, build the containers:
docker-compose up -d --build

Second, apply these codes in Bash to configure the medtest sql database :
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/00_logging.sql
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/01_create_tables.sql
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/02_create_functions.sql
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/03_initialize_keys.sql
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/04_insert_test_data.sql
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest < mysql/sql/05_grant_access_control.sql

If using Window CMD, apply these codes instead of the upper codes :
type mysql\sql\00_logging.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest
type mysql\sql\01_create_tables.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest
type mysql\sql\02_create_functions.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest
type mysql\sql\03_initialize_keys.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest
type mysql\sql\04_insert_test_data.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest
type mysql\sql\05_grant_access_control.sql | docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword medtest

Third, enter the medtest sql database with different users :
docker exec -it medtest_lab-db-1 mysql -uroot -prootpassword medtest
docker exec -it medtest_lab-db-1 mysql -umedtest_user -puserpassword medtest
docker exec -it medtest_lab-db-1 mysql -umedtest_labstaff -plabstaffpassword medtest
docker exec -it medtest_lab-db-1 mysql -umedtest_secretary -psecretarypassword medtest

Fourth, verify the setup in different users :
SELECT username, decrypt_data(email, role) AS Email, Role FROM users;
SELECT decrypt_data(name, 'patient') AS Name, decrypt_data(date_of_birth, 'patient') AS Date_of_Birth FROM patients;

Fiveth, check TDE status :
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword -e "SELECT TABLE_SCHEMA, TABLE_NAME, CREATE_OPTIONS FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'medtest' AND CREATE_OPTIONS LIKE '%ENCRYPTION%';"

Sixth, check more detailed encryption :
docker exec -i medtest_lab-db-1 mysql -uroot -prootpassword -e "SHOW TABLE STATUS FROM medtest;"