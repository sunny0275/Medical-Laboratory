DELETE FROM role_keys;
DELETE FROM encryption_keys;

INSERT INTO encryption_keys (key_value, active) VALUES
(UNHEX(SHA2('admin_key', 512)), TRUE),
(UNHEX(SHA2('lab_staff_key', 512)), TRUE),
(UNHEX(SHA2('secretary_key', 512)), TRUE),
(UNHEX(SHA2('patient_key', 512)), TRUE);

INSERT INTO role_keys (role_id, key_id) VALUES
('admin', 1),
('lab_staff', 2),
('secretary', 3),
('patient', 4);
