USE medtest;

-- Drop existing trigger
DROP TRIGGER IF EXISTS log_suspicious_query;

-- Enable query logging
SET GLOBAL general_log = 'ON';
SET GLOBAL general_log_file = '/var/lib/mysql/query.log';
SET GLOBAL log_output = 'FILE';

-- Create logging triggers
DELIMITER //
CREATE TRIGGER log_suspicious_query
AFTER INSERT ON query_log
FOR EACH ROW
BEGIN
    IF NEW.suspicious = 1 THEN
        INSERT INTO alert_log (query_id, alert_message)
        VALUES (NEW.id, CONCAT('Suspicious query detected from user ', NEW.user_id));
    END IF;
END//
DELIMITER ;
